#pragma once
#include <iostream>

enum class Campus {Trondheim, Ålesund, Gjøvik};

