#include <iostream>
#include "Dummy.h"
#include "Oppgave1.h"
#include "Matrix.h"

int main() {
	std::cout << "FIRST LINE" << std::endl << std::endl;
	Matrix A(2);
	Matrix B(2);
	Matrix C(2);

	A.set(0, 0, 1.0);
	A.set(0, 1, 2.0);
	A.set(1, 0, 3.0);
	A.set(1, 1, 4.0);

	B.set(0, 0, 4.0);
	B.set(0, 1, 3.0);
	B.set(1, 0, 2.0);
	B.set(1, 1, 1.0);

	C.set(0, 0, 1.0);
	C.set(0, 1, 3.0);
	C.set(1, 0, 1.5);
	C.set(1, 1, 2.0);
	
	
	// std::cout << A << std::endl << B << std::endl << C;
	A += B + C;
	std::cout << A << std::endl << B << std::endl << C;
	return 0;
}