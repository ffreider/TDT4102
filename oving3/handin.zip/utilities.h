#pragma once

int randomWithLimits(int upper, int lower); 
void playTargetPractice();
