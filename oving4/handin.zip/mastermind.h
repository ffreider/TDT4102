#include "std_lib_facilities.h"
#pragma once    
int checkCharactersAndPosition(string guess, string code);
int checkCharacters(string guess, string code);
void playMastermind();
